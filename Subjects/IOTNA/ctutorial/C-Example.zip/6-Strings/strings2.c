#include <stdio.h>
#include <string.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. The code of fcuntion 'copy' does not work. Why?
 * 2. Use now 'copy2()'. Does the copy actually work?
 * 3. Suggest a valid implementation for a copy
 * 4. What does function "mod" do? 
 * 5. Uncomment last line of code (call to mod()). Compile and execute. Why is there an error now?
 ************** */

void copy2(char* org, char** dst) {
	*dst = org;
}

void copy(char* org, char* dst) {
	dst = org;
}

void mod(char* org, char* dst) {
	int i;

	for (i=0;i<strlen(org);i++)
		dst[i] = org[i] - 32;

}

int main() {

	char* cad1 = "original";          
	char* cad2 = "other";
	char cad3[32];

	copy(cad1,cad2);
	//copy2(cad1,&cad2);
	printf("cad1 %s cad2 %s\n", cad1,cad2);

	mod(cad1,cad3);
	printf("cad1 %s cad3 %s\n", cad1,cad3);
	
	//mod(cad1,cad1);
}

