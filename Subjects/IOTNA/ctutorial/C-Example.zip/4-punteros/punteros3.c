#include <stdio.h>
#include <stdlib.h>
/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 *  1. Why the value of ptr[13] is changed after the sentence ptr = &c;
 *  2. This code has (at least) one bug. Compile or run-timer error? Why?
 *  3. What happens with the memory allocated by malloc()  after the assignment ptr=&c? 
 *     How can we reach that memory again? How can we free it?
 *  ***********/
int nelem;
int c;
int main(void) {
	int *ptr;
	int i;

	c = 37;	
	nelem = 127;
	ptr = (int*) malloc(nelem*sizeof(int));
	for (i=0; i<nelem; i++)
		ptr[i] = i;

	printf("ptr[0]= %d ptr[13]=%d \n",ptr[0],ptr[13]);	

	ptr = &c;
	printf("ptr[0]= %d ptr[13]=%d \n",ptr[0],ptr[13]);	

	free(ptr);
}

