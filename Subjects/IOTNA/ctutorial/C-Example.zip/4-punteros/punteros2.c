#include <stdio.h>
#include <stdlib.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 *  1. How many bytes are allocated in memory with the malloc() call?
 *  2. Which are the addresses of the first and last bytes of the allocated area?
 *  3. Why the content of the address pointed by "ptr" is 7 and not 5 in the first printf()?
 *  4. Why the content of ptrg[1] is modified after the sentence *ptr2=15 ?
 *  5. Suggest two different ways of writting the value 13 in the address of ptr[100] 
 *  6. There is a bug in the code. Even if nothing goes wrong,the bug is there. Where?
 *  ***********/
int nelem;

int main(void) {
	int *ptr;
	int * ptr2;	

	nelem = 127;
	ptr = (int*) malloc(nelem*sizeof(int));
	*ptr = 5;
	ptr[0] = 7;
	ptr2 = ptr;

	printf("Address pointed by ptr %p. Content of that address: %d \n",ptr,*ptr);	

	ptr[1] = 10;	
	printf("Address pointed by ptr[1] %p. Content of that address: %d \n",&ptr[1],ptr[1]);	

	ptr2++;
	*ptr2 = 15;
	printf("Address pointed by ptr[1] %p. Content of that address: %d \n",&ptr[1],ptr[1]);	


	free(ptr);	
	*ptr = 3;
	printf("Address pointed by ptr %p. Content of that address: %d \n",ptr,*ptr);	
}
