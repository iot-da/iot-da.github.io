#include <stdio.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. Why the assignment using pointer 'p' does not overwrite completely 'a'?
 * 2. How is modified the address pointed by 'p' after the assignment p=p+1
 * 3. How would it be different if 'p' is declared as 'short *'
 *
 ************** */
int a = 3;
int b;
char * p;
int c;
int main() {

	printf("a = %x Address of a: %p \n",a,&a);
	p = (char*) &a;
	p=p+1;
	*p= 0x1f;
	printf("a = %x. Address pointed by p:%p \n",a,p);
	
	a = 3;
	b = 0x00001f00;
	a= a | b;
	
	printf("a = %x. Address pointed by p:%p \n",a,p);
}
