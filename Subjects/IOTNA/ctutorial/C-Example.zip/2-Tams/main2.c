#include <stdio.h>


/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. Is there a compilation problem or a execution problem?
 * 2. Why is it complaining? Fix it and compila again.
 * 3. a,b,c, y x are declared one after the other. Are their addresses consecutive in memory?
 * 4. What does the modifer "%lu" means in printf()? 
 * 5. Which address is "pc" pointed to? Is the address of any other variable? Are those two the same size?
 * 6. Does the size of "array1" matches the number of elements? Why?
 * 7. Do "cadena1" and "cadena2 "point to the same address? 
 * 8. Why sizes (according to sizeof()) of cadena1 and cadena2 are different?
 *************/

#define ARRAY_SIZE  10

int a = 7;
unsigned long b = 8;
short c;
char x;
char* pc;

int array1[ARRAY_SIZE];
int array2[a]; 

char* cadena1 = "CADENA DE CARACTERES";	
char cadena2[] = "CADENA DE CARACTERES";
int main() {
	pc =&x;
	a = 16;
	printf("Adress of a: %p Tam: %lu \n",&a,sizeof(a));
	printf("Adress of b: %p Tam: %lu \n",&b,sizeof(b));
	printf("Adress of c: %p Tam: %lu \n",&c,sizeof(c));
	printf("Adress of x: %p Tam: %lu \n",&x,sizeof(x));
	printf("Adress of pc: %p Adress pointed by pc: %p Tam: %lu \n",&pc,pc,sizeof(pc));
	printf("Adress of array: %p Adress of elem 0: %p Tam de array: %lu \n",array1, &array1[0], sizeof(array1));
	printf("Adress of cadena1: %p Adress pointed by: %p Tam: %lu \n",&cadena1,cadena1,sizeof(cadena1));
	printf("Adress of cadena2: %p DAdress pointed by: %p Tam: %lu \n",&cadena2,cadena2,sizeof(cadena2));	
return 0;
}
