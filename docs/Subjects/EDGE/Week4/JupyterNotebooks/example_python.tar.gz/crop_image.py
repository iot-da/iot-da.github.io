import cv2 as cv
import sys

img = cv.imread('imgs/lena.png')
if img is None:
    sys.exit('Could not read the image.')

[h,w,c] = img.shape

print('height='+str(h)+' width='+str(w))


# Cropping
img_cropped = img[80:280, 150:500]


cv.imshow("Cropped window", img_cropped)
k = cv.waitKey(0)

cv.imwrite('imgs/lena_cropped.png', img_cropped)
k = cv.waitKey(0)
