import cv2 as cv
import sys

img = cv.imread('imgs/lena.png')
if img is None:
    sys.exit('Could not read the image.')

[w,h,c] = img.shape

# Resize to 100x200
img_resize = cv.resize(img, (100,200), interpolation= cv.INTER_LINEAR)

cv.imshow("Resize window", img_resize)
k = cv.waitKey(0)
