import cv2 as cv
import sys

img = cv.imread('imgs/lena.png')
if img is None:
    sys.exit('Could not read the image.')
gray_image = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
cv.imshow("Gray window", gray_image)
k = cv.waitKey(0)
