
#include <stdio.h>
#include <stdlib.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. Which operand should we use to declae a variable as a ponter?
 * 2. How do we obtain the address of a variable?
 * 3. How do we read/write into the address pointed by a pointer? 
 * 4. There ¡s a bug in the code. Is it a compile-time or executiontime errror? Why does it happen?
  ***********/
int c = 7;
int main(void) {

	int *ptr;
	printf("Address of ptr %p. ptr apunta a %p. Address of c: %p Valor of c %d\n",&ptr,ptr,&c,c);	

	ptr = &c;
	printf("Address of ptr %p,. ptr apunta a %p. Address of c: %p Value of c %d\n",&ptr,ptr,&c,c);	
	
	*ptr=4;
	printf("ptr apunta a %p. Content of address of ptr: %d Address of c: %p Value of c %d\n",ptr,*ptr,&c,c);	

	ptr =  (int*) 0x600a48;
	printf("Address of ptr %p. Value of c %d\n",ptr,c);	
	
	*ptr =13;
	printf("Address of ptr %p. Value of c %d\n",ptr,c);	

return 0;
	
}

