#include <stdio.h>
#include <stdlib.h>
/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 *  1. Why the second printf() prints a different value for 'd'?
 *  2. What is 'f'? A variable? A function?
 *  3. Use the function 'opera()' to perform the first addition. Then, use it again to perform a substraction.
 *  4. Using typedef, build a type called ptrToFunc with the same prototype thatn 'f'
 *  5. Creat a function 'choose()' that will return, alternatively, a pointer to "add()" and "sub()" 
 *     every time it is called
 *  ***********/

int add (int x, int y);
int sub(int x, int y);

int (*f)(int a, int b);

int add(int x, int y) {
	return x+y;
}

int sub(int x, int y) {
	return x-y;
}

int opera(int x, int y, int (*g)(int, int)) {
	return g(x,y);
}

int main(void) {

	int a = 12;
	int b =	 8;
	int c,d;

	f = add;
	c = add(a,b);
	d = f(a,b);
	printf("c = %d d= %d \n",c,d);	
	f = sub;
    d = f(a,b);
	printf("c = %d d= %d \n",c,d);
}

