#include <stdio.h>
#include <string.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. The code has a bug. Compile or run-time? Why?
 * Fix the bug commenting the line(s) that produce it. Compile and execute again. 
 * 2. Which is the address of letter 'B' in the chain "Bonjour"? And letter 'j'?
 * 3. After the assignment p=msg2; how can we get back the address of "Bonjour"?
 * 4. Why the length of strings 'p' and 'msg2' are 2 after the third assignment?
 *    3 bytes are assigned to 'p', but then the length is only 2 !!
 * 5. Why strlen() returns a different value than sizeof()?
 * 6. Why the string stored in 'msg' in line 36 is bad-printed in the last printf()?
 ************** */
int main() {

char msg[10]; /* array of 10 chars */
char *p;          /* pointer to a char */

char msg2[28]="Hello";  /* msg2 = 'H' 'e' 'l' 'l' 'o' '\0' */
     
	p   = "Bonjour"; 
	printf("msg: %s, p: %s, msg2: %s\n",msg,p,msg2);
	printf("dir de msg: %p, dir de p: %p, dir de msg2: %p\n",msg,p,msg2);

	p = msg2;
	printf("msg: %s, p: %s, msg2: %s\n",msg,p,msg2);
	printf("dir de msg: %p, dir de p: %p, dir de msg2: %p\n",msg,p,msg2);

 	p[0] = 'H', p[1] = 'i',p[2]='\0';
	printf("msg: %s, p: %s, msg2: %s\n",msg,p,msg2);
	printf("msg len: %lu p len %lu msg2 len %lu\n", strlen(msg),strlen(p),strlen(msg2));
	printf("msg size: %lu p size %lu msg2 size %lu\n", sizeof(msg),sizeof(p),sizeof(msg2));

	msg[0] = 'B', msg[1] = 'y';
	printf("msg: %s, p: %s, msg2: %s\n",msg,p,msg2);

	msg = "Goodbye";
	printf("msg: %s, p: %s, msg2: %s\n",msg,p,msg2);
}

