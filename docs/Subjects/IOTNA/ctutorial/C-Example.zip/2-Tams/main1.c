#include <stdio.h>
/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. Why the first "printf" prints different values for the same variable 'a'?
 * 2. How largeais a 'char' variable?
 * 3. Why the value of 'a' changes that much when adding 1?  
 * 4. If "long" and "double" have the same size, what's the difference?
 *****/
char a = 127;
int b = 41;
int main() {

	printf("a = %d a = %c \n", a,a);
	a++;
	printf("a = %d a = %c b=%d  b=%c\n", a,a,b,b);
	printf("Size of int: %lu\n",sizeof(int ) );
	printf("Size of char: %lu\n",sizeof( char) );
	printf("Size of float: %lu\n",sizeof(float ) );
	printf("Size of double: %lu\n",sizeof( double) );
	printf("Size of long: %lu\n",sizeof(long ) );
	printf("Size of short: %lu\n",sizeof( short) );
	printf("Size of void*: %lu\n",sizeof( void*) );

}
