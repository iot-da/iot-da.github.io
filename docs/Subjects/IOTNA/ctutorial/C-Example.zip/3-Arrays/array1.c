#include <stdio.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 * 1. Should we use "&list" to get the address of the array?
 * 2. What is actually stored in the address of "list"?
 * 3. Why are we including the lentgh of the array as parameter to "init_array"?
 * 4. Why the sizeof() output is different for the array in "init_array" and the one in main()?
 * 5. Why aren't we inclugind a second parameter in init_array2?
 * 6. Do sizeof() outuput now match with the array in init_array2()?
 ***************/

#define N 5

void init_array(int array[], int size) ;
void init_array2(int array[N]);

int main(void) {
	int i,list[N];
	printf("Dir de list %p Dir de list[0]: %p  Dir de list[1]: %p. Sizeof list %lu \n",list,&list[0],&list[1],sizeof(list));
	
	init_array(list, N);
	for (i = 0; i < N; i++)
		printf("next: %d ", list[i]);
	printf("\n-------------------------\n");

	init_array2(list);
	for (i = 0; i < N; i++)
		printf("next: %d ", list[i]);
	printf("\n-------------------------\n");
}

void init_array(int array[], int size) { 
	int i;
	printf("Direccion de array: %p Sizeof array %lu \n", array, sizeof(array));
	for (i = 0; i < size; i++)
		array[i] = i;
	printf("Array initialized\n\n");
}

void init_array2(int array[N]) { 
	int i;
	printf("Direccion de array: %p Sizeof array %lu \n", array, sizeof(array));
	for (i = 0; i < N; i++)
		array[i] = i*2;
	printf("Array initialized\n\n");
}


