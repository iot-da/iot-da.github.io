#include <stdio.h>

/**** QUESTIONS/TASKS ********
 * Compile and execute the code. 
 *  1. Does the copy of the array works? Why? 
 *  2. Fix it.
 *  3. Uncommnet the call to function "tom". Compile again and execute.
 *  4. The problem that arises, is it in compilation or execution time? Why?
 *  5. Find a value for MAXVALID (greater than 4) when the problem does not happen. Why does it work?
*******************/

#define N 10
#define MAXELEM 5000
#define MAXVALID 100

// funcion que imprime por pantalla el conteniod del array v de tam. size
void imprimeArray(int v[],int size) {
	int i;
	printf("-------------------\n");
	for (i=0;i<size;i++)
		printf("%d ",v[i]);
	printf("\n\n");

}

// funcion que copia el contenido de un array en otro
void copyArray(int src[],int dst[],int size) {
 	dst = src;
}

void tmo() {
	int x = -1; 
	int a[4] = {0,1,2,3};	 
	int b = 10000;
	int c = -1;
	int i;

	for  (i=4;i<MAXVALID;i++)
		a[i]=i;

	printf("x %d b %d c %d\n", x,b,c);

			
}

int main() {
	int A[N] = {4,3,8,5,6,9,0,1,7,2};
	int B[N];
	
	//tmo();
	copyArray(A,B,N);
	imprimeArray(B,N);
		
}
