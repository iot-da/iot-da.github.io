#include <stdio.h>

/******** QUESTIONS/TASKS *****
* 1. Compile and execute the code
* 2. Later, apply only the preprocessor  (-E flag) and redirect the output
* to a file called hello.i
3. What happened to the call min()?
* 4. What did the directive  #include <stdio.h> produced?
*****************/



#define N 5

#define min(x,y) ( (x<y)?x:y )
int a = 7;
int b = 9;
int main() {

 char* cad = "Hello world";
 int i;

 for (i=0;i<N;i++) {
   printf("%s \t a= %d b= %d\n",cad,a,b);
   a++;
   a = min(a,b);			
 }
 return 0;
}
